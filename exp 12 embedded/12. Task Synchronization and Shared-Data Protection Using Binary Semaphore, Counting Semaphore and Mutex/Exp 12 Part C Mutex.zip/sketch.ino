// Experiment 12 - Program C: Mutex for shared-data protection
// Run once with USE_MUTEX 1, then once with USE_MUTEX 0 and compare.
#include <Arduino.h>
 
#define USE_MUTEX 1      // 1 = protected, 0 = unprotected (race condition)
#define UPDATES   10     // increments done by each task
 
SemaphoreHandle_t counterMutex;
int sharedCounter = 0;
volatile int tasksFinished = 0;
 
void lockCounter()   { if (USE_MUTEX) xSemaphoreTake(counterMutex, portMAX_DELAY); }
void unlockCounter() { if (USE_MUTEX) xSemaphoreGive(counterMutex); }
 
void CounterTask(void *pvParameters) {
  int id = (int)(intptr_t)pvParameters;
  for (int i = 0; i < UPDATES; i++) {
    lockCounter();                       // ---- critical section starts
    int temp = sharedCounter;            // read
    vTaskDelay(pdMS_TO_TICKS(10));       // slow update: other task may run here
    sharedCounter = temp + 1;            // write back
    Serial.printf("[MUTEX] Task %d counter = %d\n", id, sharedCounter);
    unlockCounter();                     // ---- critical section ends
    vTaskDelay(pdMS_TO_TICKS(id == 1 ? 50 : 70));
  }
  tasksFinished = tasksFinished + 1;
  vTaskDelete(NULL);
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.printf("MUTEX - SHARED DATA PROTECTION (USE_MUTEX = %d)\n", USE_MUTEX);
  counterMutex = xSemaphoreCreateMutex();
  if (counterMutex == NULL) {
    Serial.println("ERROR: Mutex creation failed");
    while (1) vTaskDelay(pdMS_TO_TICKS(1000));
  }
  xTaskCreatePinnedToCore(CounterTask, "Counter1", 4096, (void*)1, 1, NULL, 1);
  xTaskCreatePinnedToCore(CounterTask, "Counter2", 4096, (void*)2, 1, NULL, 1);
}
 
void loop() {
  static bool reported = false;
  if (tasksFinished == 2 && !reported) {
    Serial.printf("FINAL sharedCounter = %d (expected %d)\n", sharedCounter, 2 * UPDATES);
    reported = true;
  }
  vTaskDelay(pdMS_TO_TICKS(200));
}
